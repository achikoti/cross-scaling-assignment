public class MainClass101{
	public static void main(String[] str){
		int org=123,a=0,dup=org,rev=0,rem;
		while(dup!=0){
			rem=dup%10;
			rev=rev*10+rem;
			dup=dup/10;
		}
		if(rev == org)
			System.out.println(org+" is palindrome");
		else
			System.out.println(org+" is not palindrome");
	}
}