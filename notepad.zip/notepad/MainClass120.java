public class MainClass120{
	public static void main(String [] str){
		int []a={1,2,11,12,13,123,234,1,2,3,4,5};
		int c=0,j=0,k=0,l=0;
		for(int i=0;i<a.length;i++){
			while(a[i]>0){
				a[i]=a[i]/10;
				c++;
			}
			if(c==1){
			j=j+1;
			}
			else if(c==2){
			k=k+1;
			}
			else{
			l=l+1;
			}
		c=0;
		}
			System.out.print("1 digit"+j+"2 digit"+k+"3 digit"+l);

	}
}