public class MainClass0{
	public static void main(String[] str){
				System.out.println("Welcome to Java World, Abhinav !!!");
	}
}