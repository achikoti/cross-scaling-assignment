public class MainClass12{
	public static void main(String[] str){
		for(int i=1;i<11;i++){
				
				System.out.println((2*i)+"  "+(3*i)+"  "+(4*i)+"  "+(5*i)+"  "+(6*i)+"  "+(7*i)+"  "+(8*i)+"  "+(9*i)+"  "+(10*i));
		
		}
		for(int i=1;i<=10;i++){
			for(int j=1;j<=10;j++)
				System.out.print(i*j+"\t");
			System.out.println("\n");
		}
		
	}
}