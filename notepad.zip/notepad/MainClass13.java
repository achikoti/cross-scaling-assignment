public class MainClass13{
	public static void main(String[] str){
		
		for(int i=1;i<=10;i++){
			for(int j=1;j<=10;j++){
				System.out.print(((10*i)+j)+"\t");
				
			}
			System.out.println("\t");
		}
		
	}
}
			