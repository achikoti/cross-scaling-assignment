public class MainClass114{
	public static void main(String[] str){
		int n=6,ftl=1;
		for(int i=n;i>0;i--)
			ftl = ftl * i;
		System.out.print(ftl+" is the factorial of "+n);
	}
}